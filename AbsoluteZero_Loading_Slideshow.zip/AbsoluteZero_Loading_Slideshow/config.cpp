class CfgPatches
{
	class AbsoluteZero_Loading_Slideshow
	{
		units[]={};
		weapons[]={};
		requiredVersion=1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Gear_Consumables",
			"DZ_Vehicles_Wheeled",
			"DZ_Structures_Residential",
			"DZ_Sounds_Effects",
			"DZ_Sounds_Weapons"
		};
	};
};
class CfgMods
{
	class AbsoluteZero_Loading_Slideshow
	{
		dir="AbsoluteZero_Loading_Slideshow";
		picture="";
		action="";
		hideName=1;
		hidePicture=1;
		name="AbsoluteZero_Loading_Slideshow";
		credits=" Drox & R0Lu ";
		author="R0Lu";
		authorID="0";
		version="1.0";
		extra=0;
		type="mod";
		dependencies[]=
		{
			"Game"
		};
		class defs
		{
			class gameScriptModule
			{
				value="";
				files[]=
				{
					"AbsoluteZero_Loading_Slideshow/scripts/3_Game"
				};
			};
		};
	};
};
