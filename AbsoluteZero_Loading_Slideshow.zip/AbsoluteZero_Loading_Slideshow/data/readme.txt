Add your 5 .edds files in this folder.

The files must use the following naming convention. Make sure to rename them as:

Loading_01.edds
Loading_02.edds
Loading_03.edds
Loading_04.edds
Loading_05.edds

